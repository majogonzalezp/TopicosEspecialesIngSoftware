<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', 'App\Http\Controllers\HomeController@index')->name("home.index");

Route::get('/about', function () {
    $data1 = "About us - Online Store";
    $data2 = "About us";
    $description = "This is an about page ...";
    $author = "Developed by: María José González";
    return view('home.about')
    ->with("title", $data1)
    ->with("subtitle", $data2)
    ->with("description", $description)
    ->with("author", $author);
})->name("home.about");


Route::get('/contact', function () {

    $data1 = "Contact - Online Store";
    $data2 = "Contact us";
    $email = "mjgp@gmail.com";
    $adress = "Cra. 50 #20 Sur, Medellín";
    $phone = "+57 320478560";
    return view('home.contact')
    ->with("title", $data1)
    ->with("subtitle", $data2)
    ->with("email", $email)
    ->with("adress", $adress)
    ->with("phone", $phone);
})->name("home.contact");


Route::get('/gusanos', 'App\Http\Controllers\GusanoController@index')->name("gusano.index");
Route::get('/gusanos/create', 'App\Http\Controllers\GusanoController@create')->name("gusano.create");
Route::post('/gusanos/save', 'App\Http\Controllers\GusanoController@save')->name("gusano.save");
Route::get('/gusanos/estadisticas', 'App\Http\Controllers\GusanoController@estadisticas')->name("gusano.estadisticas");
Route::get('/gusanos/{id}', 'App\Http\Controllers\GusanoController@show')->name("gusano.show");
