@extends('layouts.app')
@section('title', $viewData["title"])
@section('subtitle', $viewData["subtitle"])
@section('content')
    @foreach ($viewData["tipo"] as $tipo)
        <p>{{ $tipo->tipo }}: {{ $tipo->total }} gusanos</p>
    @endforeach

        <p>Velocidad promedio: {{ $viewData["velocidad"] }}</p>
</body>
</html>
@endsection