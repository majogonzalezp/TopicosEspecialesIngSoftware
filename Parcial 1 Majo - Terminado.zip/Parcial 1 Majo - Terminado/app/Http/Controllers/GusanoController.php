<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\View\View;
use App\Models\Gusano;
use Illuminate\Support\Facades\DB;

class GusanoController extends Controller
{
    

    public function index(): View
    {
        $viewData = [];
        $viewData["title"] = "Gusanos - Parcial 1";
        $viewData["subtitle"] =  "Gusanos";
        $viewData["gusanos"] = Gusano::all();
        //$viewData["gusanos"] = GusanoController::$gusanos;
        return view('gusano.index')->with("viewData", $viewData);
    }

    public function show(string $id) : View
    {
        $viewData = [];
        $gusano = Gusano::findOrFail($id);
        //$gusano = GusanoController::$gusanos[$id-1];
        $viewData["title"] = $gusano["nombre"]." - Parcial 1";
        $viewData["subtitle"] =  $gusano["nombre"]." - Info gusano";
        $viewData["gusano"] = $gusano;
        return view('gusano.show')->with("viewData", $viewData);
    }

    public function create(): View
    {
        $viewData = []; 
        $viewData["title"] = "Crear gusano";

        return view('gusano.create')->with("viewData",$viewData);
    }

    public function save(Request $request): \Illuminate\Http\RedirectResponse
    {
        $request->validate([
            "nombre" => "required",
            "tipo" => "required",
            "velocidad" => "required"

            
        ]);
        
        Gusano::create($request->only(["nombre","tipo", "velocidad"]));

        return back();
        
    }

    public function estadisticas()
    {
        $viewData = [];
        $viewData['title'] = 'Estadísticas';
        $viewData['subtitle'] = 'Estadísticas gusano';
        $viewData['velocidad'] = Gusano::avg('velocidad');
        $viewData['tipo'] = Gusano::select('tipo', DB::raw('count(*) as total'))
            ->groupBy('tipo')
            ->get();


        return view('gusano.estadisticas')->with('viewData', $viewData);
    }

}



