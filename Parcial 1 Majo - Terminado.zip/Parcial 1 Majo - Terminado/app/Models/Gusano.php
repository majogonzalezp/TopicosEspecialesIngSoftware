<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gusano extends Model
{
    use HasFactory;




    protected $fillable = ['nombre','tipo', 'velocidad'];

    public function getId(): int

    {

    return $this->attributes['id'];

    }

    public function setId($id) : void

    {

    $this->attributes['id'] = $id;

    }

    public function getNombre(): string

    {

    return $this->attributes['nombre'];

    }

    public function setNombre($nombre) : void

    {

    $this->attributes['nombre'] = $nombre;

    }

    public function getTipo(): string

    {

    return $this->attributes['tipo'];

    }

    public function setTipo($tipo) : void

    {

    $this->attributes['tipo'] = $tipo;

    }

    public function getVelocidad(): int

    {

    return $this->attributes['velocidad'];

    }

    public function setVelocidad($velocidad) : void

    {

    $this->attributes['velocidad'] = $velocidad;

    }

}
