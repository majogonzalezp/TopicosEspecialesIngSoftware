
<?php $__env->startSection('title', $viewData["title"]); ?>
<?php $__env->startSection('subtitle', $viewData["subtitle"]); ?>
<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $viewData["tipo"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($tipo->tipo); ?>: <?php echo e($tipo->total); ?> gusanos</p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <p>Velocidad promedio: <?php echo e($viewData["velocidad"]); ?></p>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TopicosIngSoftware\Parcial 1 Majo - Terminado\resources\views/gusano/estadisticas.blade.php ENDPATH**/ ?>