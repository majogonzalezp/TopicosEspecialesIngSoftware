    
    <?php $__env->startSection('title', $viewData["title"]); ?>
    <?php $__env->startSection('subtitle', $viewData["subtitle"]); ?>
    <?php $__env->startSection('content'); ?>
    <div class="card mb-3">
    <div class="row g-0">
        <div class="col-md-4">
        <img src="https://laravel.com/img/logotype.min.svg" class="img-fluid rounded-start">
        </div>
        <div class="col-md-8">
        <div class="card-body">
            <h5 class="card-title">
            <?php echo e($viewData["gusano"]["nombre"]); ?>

            </h5>
            <p class="card-text"><?php echo e($viewData["gusano"]["tipo"]); ?></p>
            <p class="card-text"><?php echo e($viewData["gusano"]["velocidad"]); ?></p>
        </div>
        </div>

    </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TopicosIngSoftware\Parcial 1 Majo\resources\views/gusano/show.blade.php ENDPATH**/ ?>