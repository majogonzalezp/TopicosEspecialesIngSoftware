
<?php $__env->startSection('title', 'Home Page - Online Store'); ?>
<?php $__env->startSection('content'); ?>
<div class="text-center">
    Welcome to the application
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TopicosIngSoftware\Parcial 1 Majo - Terminado\resources\views/home/index.blade.php ENDPATH**/ ?>